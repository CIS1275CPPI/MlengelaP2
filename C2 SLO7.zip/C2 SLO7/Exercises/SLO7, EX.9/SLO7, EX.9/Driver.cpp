/*******************************************************************************************
* Program: The use of C++ CMath library
* Programmer: Daudi Mlengela (dmlengela@cnm.edu)
* Date: 15 September 2021. 
* Purpose: Write a C++ program that calculates the size of aquarium needed based on number of fish 
* and the adult size of the fish. The rule is that the aquarium should be at least 2 gallons of water 
* for each inch of adult fish.  The store sells  aquariums in these sizes:  20, 40, 60, 80 gallons.
* Declare variables for the number of fish(int) , the adult length of the fish (double)
* and the size of the aquarium calculated. Ask the user for the type of fish they want.
* Ask the user the adult size of these fish.  Ask the user how many fish they want. 
* Calculate the total inches of fish desired by the user.
* Calculate the number of gallons of water needed for the aquarium.
* Round up the number using ceil. Use an if, if-else, else structure to figure out 
* which of the store�s tanks will be big enough for the fish.
* Use logic to make sure you place the fish in the correct tank.
* Also, if there are too many fish for the store�s tanks, 
* then tell the user that the tanks in the store are not big enough. 
* Display the number of fish, their size and the size of the tank.
*********************************************************************************************/
#include <iostream>
#include <string>

using namespace std;

int main()
{
	int numFish{ 0 };
	double adultSize{ 0.0 }; // in inches
	double totalInches{ 0.0 }; //total inches of fish
	double totalGallons{ 0 };  // amount of water needed
	int storeTankSize{ 20 };

	/*Get the information from the user */
	cout << "\n Please enter the number of fish for your tank: ";
	cin >> numFish;
	cout << "\n Please enter the adult size of the fish (in inches) ";
	cin >> adultSize;

	/*Calculate the gallons needed */
	totalInches = numFish * adultSize;
	totalGallons = totalInches * 2.0; 

	/*Check if a store aquarium will work*/ 
	if (totalGallons <= 20.0)
		storeTankSize = 20;
	else if (totalGallons <= 40.0)
		storeTankSize = 40;
	else if (totalGallons <= 60.0)
		storeTankSize = 60;
	else if (totalGallons <= 80)
		storeTankSize = 80;
	else
		storeTankSize = 99;

	/* cout the results */

	if (storeTankSize == 99)
	{
		cout << "\n Sorry, this store does not have a big enougth tank for you! ";

	}
	else
	{
		cout << "\n Hello, your " << numFish <<" fish that will grow to be "
			<< adultSize << " inches long, \n will be happy in a tank "
			<< " that is " << storeTankSize << " gallons ";
	}
	cout << endl << endl; 


	return 0;
}