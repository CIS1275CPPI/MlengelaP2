/***********************************************************************************************
* Program: Switch Statements.
* Programmer: Daudi Mlenglea (dmlengela@cnm.edu)
* Date: 15 September 2021.
* Purpose: To write a c++ program that uses a switch statement to determine the user's choice of a car
* to buy. Show a menu to the user telling them the names of the 4 cars for sale. This can be done with
* cout statements. Put a number in front of each choice so the user can choose a number. Tell the user
* to enter the number of the car they want to buy.
************************************************************************************************/
#include <iostream>
#include <string>

using namespace std;

int main()

{
	int choice{ 1 };
	cout << "\n The cars for sale are: ";
	cout << "\n 1. Chevy Silvarado ";
	cout << "\n 2. Ford Focus ";
	cout << "\n 3. Toyota Camry ";
	cout << "\n 4. Honda Accord ";
	cout << "\n please enter the number of your choice: ";
	cin >> choice;

	cout << "\n You choose a "; 

	switch (choice)
	{
	case 1: 
		cout <<" Chevy Silvarado ";
		break;
	case 2: 
		cout << "Ford Focus ";
		break;
	case 3:
		cout << "Toyota Camry ";
		break;
	case 4: 
		cout << "Honda Accord ";
		break;
	default:
		cout << "\n Not in our inventory, sorry. ";

	}

	return 0;
}