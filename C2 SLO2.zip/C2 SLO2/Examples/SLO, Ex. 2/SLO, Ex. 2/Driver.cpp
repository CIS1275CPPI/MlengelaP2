/***********************************************************************************************
* Program: Conditional Expressions in Statements that 
* allows execusion of branches corresponding to true or false. 
* Programmer: Daudi Mlenglea (dmlengela@cnm.edu)
* Date: 15 September 2021.
* Purpose: To write a program to compute the sum of two given integers. If the sum is in the range
* 10..20 inclusive return 30. Ask the user to enter two integers, read them into two int variables. 
* To calculate the sum of the two numbers. Display the answer.If it is greater than or equal to 
* 10 and less than or equal to 20, display 30. 
************************************************************************************************/
#include <iostream>
#include <string>


using namespace std;

int main()

{
	int num1{ 0 }, num2{ 0 }, sum{ 0 };
	cout << " \n Please enter two integers, with a space between them: ";
	cin >> num1 >> num2;
	
	// Calculate the sum of the two numbers.
	sum = num1 + num2;
	cout << "\n The sum of " << num1 << " + " << num2 << " is " << sum;

	if (sum >= 10 && sum <= 20)
	{
		cout << "\n displaying 30";
	}
	cout << endl << endl; 


	return 0;
}