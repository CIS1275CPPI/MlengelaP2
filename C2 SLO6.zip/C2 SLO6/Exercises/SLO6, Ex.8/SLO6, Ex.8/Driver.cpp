/***********************************************************************************************
* Program: Implement the best practices for braces in C++.
* Programmer: Daudi Mlenglea (dmlengela@cnm.edu)
* Date: 15 September 2021.
* Purpose: Write a C++ program that demonstrates the Best Practice for use of braces 
* using conditional if, else-if, else  statements.  
* Write a program that will help a person going on vacation to the ocean to determine 
* whether they should to go to the beach or visit the tourist spots. Ask them the predicted temperature 
* and weather condition for tomorrow.  Then ask them what is the weather condition predicted to be?
* Ask them to enter sunny, rainy or cloudy. If it is predicted to be cloudy and 75 degrees or warmer,
* you will say �It will be cloudy, but still beach weather!� If it is predicted to be sunny 
* and 70 degrees or warmer, you will say �It should be a perfect day at the beach,
* but take a big beach umbrella!� No matter what the temperature, if it is rainy, 
* you will say �It will be a great day to visit the local museum!� If none of these conditions apply, 
* you will say,� It might be a bit cool for the beach.  Bring a sweater!�
************************************************************************************************/
#include <iostream>
#include <string>


using namespace std;

int main()

{
	
	int temperature{ 75 };
	string weather;

	cout << "\n What is temperature predicted to be? ";
	cin >> temperature;
	cout << "\n What is the weather condition predicted to be? "
	 << "\n Choose sunny, rainy, or cloudy: "; 
	cin >> weather;

	if (weather == "sunny" && temperature >= 70)
	{
		cout << "\n It should be perfect day at the beach, "
			<< "but take a big beach umbrella! "; 
	}
	else if (weather == "cloudy" && temperature >= 75)
	{
		cout << "\n It will be cloudy, but still beach weather! "; 
	}
	else if (weather == "rainy")
	{
		cout << "\n It could be a great day to visit a local meseum! ";
	}
	else
	{
		cout << "\n It might be a bit cool for the beach. Bring a sweater! "; 
	}
	cout << endl << endl; 

	return 0;
}