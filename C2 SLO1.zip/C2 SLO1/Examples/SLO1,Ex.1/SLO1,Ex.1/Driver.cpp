/***********************************************************************************************
* Program: Relational and Comparison Operators. 
* Programmer: Daudi Mlenglea (dmlengela@cnm.edu)
* Date: 15 September 2021. 
* Purpose: Conditional used to make decisions in the program: True or false?
* Operators <=, ==, <, and !=
************************************************************************************************/
#include <iostream>

using namespace std;

int main()

{
	/*1. Conditionals are used to make decisions in the program.True or false ? */
	cout << "\n 1. Conditionals are used to make decisions in the program. True or false? ";
	cout << " \n True. They allow programs to branch depending on the conditions: ";

     /*2. Oparator >= means about the same as. True or false? */
	cout << "\n 2. Oparator >= means about the same as. True or false? ";
	cout << " \n False. > means greater than and adding = means greater than or equal to: ";

	/*3. Operator == means has the same value as. True or false?*/
	cout << "\n 3. Operator == means has the same value as. True or false? ";
	cout << " \n True. Remember, this is a comparison, not assignment! ";

	/*4. Operator < means greater than. True or false? */
	cout << "\n 4. Operator < means greater than. True or false? ";
	cout << " \n False. < means less than. ";
	/*5. Operator != means not the same as. True or false? */
	cout << "\n 5. Operator != means not the same as. True or false? "; 
	cout << " \n True. Simply NOT equal to. "; 

	return 0;
}