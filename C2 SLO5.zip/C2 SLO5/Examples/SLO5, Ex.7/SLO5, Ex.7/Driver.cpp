/***********************************************************************************************
* Program: The use of ternary Operators, which is a short-cut for a simple condition statement.
* Programmer: Daudi Mlenglea (dmlengela@cnm.edu)
* Date: 15 September 2021.
* Purpose: Write a C++ program that uses the  ternary operator to write 
* this if-else condition conditional: If more than 12 students sign up for C++ I class,
* if will  be taught.  If not, the class will be cancelled.  
* Declare tha variable for the number of students registered for a C++ I class.
* Ask the user for the number of students registered and display the result of the conditional.
************************************************************************************************/
#include <iostream>
#include <string>

using namespace std;

int main()

{
	int numRegistered{ 0 };
	string result;

	cout << "\n Please enter the number of students registered for C++ I: ";
	cin >> numRegistered;

	/*Ternary Conditional statement */
	result = numRegistered > 12 ? "\n C++ I will be taught" : "\n C++ I will be cancelled ";
	cout << result; 
	cout << endl << endl; 


	return 0;
}