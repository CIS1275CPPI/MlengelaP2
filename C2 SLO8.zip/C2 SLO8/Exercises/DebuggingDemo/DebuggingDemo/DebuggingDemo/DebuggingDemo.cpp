// DebuggingDemo.cpp n
//

#include <iostream>
using namespace std;

int main()
{
    //Progam header
    cout<<"\n Find the Volume of a Pyramid" << endl << endl; 

    //Declare variables
    double  length{ 0.0 }, height{ 0.0 };
    char comma{ ',' };
    double volPyramid{ 0.0 };

    //Ask the user for the dimensions
    cout << "\n Please enter the length and height of your pyramid, with a comma between them, ex 5, 8 " << endl
        << "        =>  ";
    cin >> length >>  height;

    //Calculate the volume
    //Volume = base* base*height / 3
    volPyramid = (pow(length, 2) * height) / 3.0;

    //Report to the user
    cout << "\n\n Based on the dimensions you gave this program:\n "
        << "length: " << length << "   height: " << height << endl
        << "\n The volume of your pyramid is:  " << volPyramid
        << " cubic feet.";    

    cout << endl << endl;
    return 0;
}

