/*******************************************************************************************
* Program: Debugging our programs. 
* Programmer: Daudi Mlengela (dmlengela@cnm.edu)
* Date: 15 September 2021.
* Purpose:Play the following video and follow along with the lesson on your computer.
* https://youtu.be/9B5DePVvT9Y?list=PLijIhvWIKC9P5coPbd0T443JWtIWDZeLp 
*********************************************************************************************/
#include <iostream>

using namespace std;

int main()
{


	return 0;
}