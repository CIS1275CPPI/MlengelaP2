/***********************************************************************************************
* Program: Nest Conditional Statements to handle multiple Conditions.
* Programmer: Daudi Mlenglea (dmlengela@cnm.edu)
* Date: 15 September 2021.
* Purpose: To write a c++ program that accept two integers and display true if either one is 5
* or their sum or their difference is 5. Ask the user to enter two integers, read them into two int
* variables. Also declare variables for the sum and difference of the two numbers. Write a conditional
* statement that will resolve to true if: 
* Number 1 is 5 or number2 is 5 or the sum is 5 or the different is 5. If the result of the conditional
* is true, display "The result is true". Otherwise, display "The result is false."
************************************************************************************************/
#include <iostream>
#include <string>

using namespace std;

int main()

{
	int num1{ 0 }, num2{ 0 }, sum{ 0 }, difference{ 0 };
	cout << "\n please enter two integers, with a space between them: ";
	cin >> num1 >> num2;

	/* Check all of the conditions: */

	if (num1 == 5 || num2 == 5 || (num1 - num2) == 5 || (num1 + num2) == 5)
	{
		cout << "\n Th result is true ";

	}
	else
	{
		cout << "\n The result is false ";
	}
	cout << endl << endl;

	return 0;
}