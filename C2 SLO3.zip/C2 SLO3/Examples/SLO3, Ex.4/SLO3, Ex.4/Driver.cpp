/***********************************************************************************************
* Program: Nest Conditional Statements to handle multiple Conditions. 
* Programmer: Daudi Mlenglea (dmlengela@cnm.edu)
* Date: 15 September 2021.
* Purpose: To write a c++ program to compute the sum of the two given integers. If the sum is in 
* range 10..20 inclusive return 30..Ask the user to enter two integers, read them into two int variables.
* Also declare variables for the sum. Write a conditional statement that will check if the sum is in
* the range of 10 to 20, inclusive. Number1 is 5 or number2 is 10 or the sum is 5 or the different is 5.
* if the result of the conditional is true, display "Displaying 30." Otherwise,
* display "Not in the range."
************************************************************************************************/
#include <iostream>
#include <string>


using namespace std;

int main()

{
	int num1{ 0 }, num2{ 0 }, sum{ 0 }, difference{ 0 };
	cout << "\n Please enter two integers, with a space between them: ";
	cin >> num1 >> num2;

	/* Check the conditions: */
	if (sum >= 10 && sum <= 20)
	{
		cout << "\n Displaying 30";
	}
	else
	{
		cout << "\n Not in the range ";
	}
	cout << endl << endl;



	return 0;
}