/***********************************************************************************************
* Program: Contrast the efficient and inefficient use of conditional statement.
* Programmer: Daudi Mlenglea (dmlengela@cnm.edu)
* Date: 15 September 2021.
* Purpose: Write a C++ program to translate the floors in a hotel to the correct number.
* You may know that there is no 13th floor in many hotels, because it is considered unlucky.
* So, in the elevator, the floor numbers are changed to bypass the  13th floor.
* Declare two variables as integers:   the displayNumber and the floorNumber.
* Write a conditional if-else statement that will check if the displayNumber is at 14 or greater than 14,
* and add one to the display number displayed if it is.
* Add a cout in each branch that displays the real floor number. 
************************************************************************************************/
#include <iostream>

using namespace std;

int main()

{
	int floorNumber{ 0 }, elevatorNumber{ 0 };
	/*Ask the user for the floor number in the elevator:*/
	cout << "\n Please enter the elevator number. ";
	cin >> elevatorNumber;

	/*Check to see if the elevatorNumber is less than or equal to 14. */
	if (elevatorNumber >= 14)
	{
	  /* cout << "\n real floor number is " << elevatorNumber --;*/
		floorNumber = elevatorNumber - 1;
	}
	else
	{
		/* cout << "\n real floor number is " << elevatorNumber << elevatorNumber --; */
		floorNumber = elevatorNumber;
	}
	cout << "\n The real floor number is " << floorNumber;
	cout << endl << endl; 

	return 0;
}